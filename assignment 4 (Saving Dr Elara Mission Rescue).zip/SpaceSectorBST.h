#ifndef SPACESECTORBST_H
#define SPACESECTORBST_H

#include <iostream>
#include <fstream>  
#include <sstream>
#include <vector>
#include <algorithm>
#include <string>

#include "Sector.h"
using namespace std;

class SpaceSectorBST {
  
public:
    Sector *root;
    SpaceSectorBST();
    ~SpaceSectorBST();
    void deleteTree(Sector* node); // Helper function to delete all nodes
    void readSectorsFromFile(const std::string& filename); 
    void insertSectorByCoordinates(int x, int y, int z);
    void deleteSector(const std::string& sector_code);
    static Sector* findSector(Sector* node, string sectorCode);
    void deleteItem(Sector* &node, const std::string& sector_code, int x, int y, int z);
    void deleteNodeItem(Sector* &node, int x, int y, int z);
    void findInorderSuccessor(Sector *&node,  string &sector_code, int &x, int &y, int &z);
    void displaySectorsInOrder();
    void displaySectorsPreOrder();
    void displaySectorsPostOrder();
    void displayInOrder(Sector* node);
    void displayPreOrder(Sector* node);
    void displayPostOrder(Sector* node);
    std::vector<Sector*> getStellarPath(const std::string& sector_code);
    bool getPath(Sector* root, const std::string& sector_code, std::vector<Sector*>& path);
    void printStellarPath(const std::vector<Sector*>& path);
    Sector* insertNode(Sector* node, int x, int y, int z);
    static int stringToInteger(const std::string& str);
};

#endif // SPACESECTORBST_H

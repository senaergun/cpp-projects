#include "SpaceSectorLLRBT.h"
#include "SpaceSectorBST.h"

using namespace std;

SpaceSectorLLRBT::SpaceSectorLLRBT() : root(nullptr) {}

void SpaceSectorLLRBT::readSectorsFromFile(const std::string& filename) {
    // TODO: read the sectors from the input file and insert them into the LLRBT sector map
    // according to the given comparison critera based on the sector coordinates.
    ifstream inputFile(filename);
    if (inputFile.is_open()) {
        string line;
        while (getline(inputFile, line)) {
            if (line != "X,Y,Z") {
                stringstream lineStream(line);
                string coordinate;
                int x, y, z;

                getline(lineStream, coordinate, ',');
                x = SpaceSectorBST::stringToInteger(coordinate);
                getline(lineStream, coordinate, ',');
                y = SpaceSectorBST::stringToInteger(coordinate);
                getline(lineStream, coordinate, ',');
                z = SpaceSectorBST::stringToInteger(coordinate);

                insertSectorByCoordinates(x, y, z);
            }
        }
        inputFile.close();
    }
}

// Remember to handle memory deallocation properly in the destructor.
SpaceSectorLLRBT::~SpaceSectorLLRBT() {
    // TODO: Free any dynamically allocated memory in this class.
    deleteTree(root);
}

void SpaceSectorLLRBT::insertSectorByCoordinates(int x, int y, int z) {
    // TODO: Instantiate and insert a new sector into the space sector LLRBT map
    // according to the coordinates-based comparison criteria.
    root = insertNode(root, x, y, z, nullptr);
    if (isRed(root)) {
        root->color = BLACK;
    }
}

void SpaceSectorLLRBT::displaySectorsInOrder() {
    // TODO: Traverse the space sector LLRBT map in-order and print the sectors
    // to STDOUT in the given format.
    cout << "Space sectors inorder traversal:" << endl;
    displayInOrder(root);
    cout << endl;
}

void SpaceSectorLLRBT::displaySectorsPreOrder() {
    // TODO: Traverse the space sector LLRBT map in pre-order traversal and print
    // the sectors to STDOUT in the given format.
    cout << "Space sectors preorder traversal:" << endl;
    displayPreOrder(root);
    cout << endl;
}

void SpaceSectorLLRBT::displaySectorsPostOrder() {
    // TODO: Traverse the space sector LLRBT map in post-order traversal and print
    // the sectors to STDOUT in the given format.
    cout << "Space sectors postorder traversal:" << endl;
    displayPostOrder(root);
    cout << endl;
}

std::vector<Sector*> SpaceSectorLLRBT::getStellarPath(const std::string& sector_code) {
    std::vector<Sector*> path;

    // TODO: Find the path from the Earth to the destination sector given by its
    // sector_code, and return a vector of pointers to the Sector nodes that are on
    // the path. Make sure that there are no duplicate Sector nodes in the path!
    std::vector<Sector*> earthPath;
    std::vector<Sector*> sectorPath;
    bool sectorFound = false;

    getPath(root, "0SSS", earthPath);
    if(getPath(root, sector_code, sectorPath)){
        sectorFound = true;
    }

    std::reverse(earthPath.begin(), earthPath.end());
    std::reverse(sectorPath.begin(), sectorPath.end());


    bool commonParentFound = false;
    Sector* commonParent = nullptr;
    for(Sector* sector: earthPath){
        for(Sector* sector1: sectorPath){
            if (sector->sector_code == sector1->sector_code){
                commonParent = sector;
                commonParentFound = true;
                break;
            }
        }
        if(commonParentFound)
            break;
    }
    earthPath.clear();
    sectorPath.clear();

    getPath(commonParent, "0SSS", earthPath);
    getPath(commonParent, sector_code, sectorPath);
    std::reverse(earthPath.begin(), earthPath.end());

    for(auto i : earthPath){
        path.push_back(i);
    }

    for (int i = 1; i < sectorPath.size(); i++){
        path.push_back(sectorPath[i]);
    }

    if(sectorFound)
        return path;
    else{
        path.clear();
        return path;
    }
}

void SpaceSectorLLRBT::printStellarPath(const std::vector<Sector*>& path) {
    // TODO: Print the stellar path obtained from the getStellarPath() function
    // to STDOUT in the given format.
    if(path.empty()){
        cout << "A path to Dr. Elara could not be found.";
    }
    else{
        cout << "The stellar path to Dr. Elara: " ;

        cout << path[0]->sector_code;

        for (size_t i = 1; i < path.size(); ++i) {
            cout << "->" << path[i]->sector_code;
        }
    }

    cout << endl;
}

void SpaceSectorLLRBT::displayInOrder(Sector* node) {
    if (node == nullptr) {
        return;
    }
    string color;
    if(node->color)
        color = "RED";
    else
        color = "BLACK";

    displayInOrder(node->left);
    cout <<  color << " sector: " << node->sector_code  << endl;
    displayInOrder(node->right);
}

void SpaceSectorLLRBT::displayPreOrder(Sector* node) {
    if (node == nullptr) {
        return;
    }
    string color;
    if(node->color)
        color = "RED";
    else
        color = "BLACK";

    cout <<  color << " sector: " << node->sector_code  << endl;
    displayPreOrder(node->left);
    displayPreOrder(node->right);
}

void SpaceSectorLLRBT::displayPostOrder(Sector* node) {
    if (node == nullptr) {
        return;
    }
    string color;
    if(node->color)
        color = "RED";
    else
        color = "BLACK";

    displayPostOrder(node->left);
    displayPostOrder(node->right);
    cout <<  color << " sector: " << node->sector_code  << endl;
}

void SpaceSectorLLRBT::deleteTree(Sector* node) {
    if (node != nullptr) {
        deleteTree(node->left);
        deleteTree(node->right);
        delete node;
        node = nullptr;
    }
}

Sector *SpaceSectorLLRBT::insertNode(Sector *node, int x, int y, int z, Sector* parent) {
    if (node == nullptr) {
        Sector* newNode = new Sector(x, y, z);
        newNode->parent = parent;
        return newNode;
    }

    if (x < node->x) {
        node->left = insertNode(node->left, x, y, z, node);
    } else if (x > node->x) {
        node->right = insertNode(node->right, x, y, z, node);
    } else {
        if (y < node->y) {
            node->left = insertNode(node->left, x, y, z, node);
        } else if (y > node->y) {
            node->right = insertNode(node->right, x, y, z, node);
        } else {
            if (z < node->z) {
                node->left = insertNode(node->left, x, y, z, node);
            } else if (z > node->z) {
                node->right = insertNode(node->right, x, y, z, node);
            }

        }
    }

    if (  isRed(node->right) && !isRed(node->left)) {
        node = rotateLeft(node);
    }

    if (isRed(node->left) && isRed(node->left->left)) {
        node = rotateRight(node);
    }

    if (isRed(node->left) && isRed(node->right)) {
        flipColors(node);

    }

    return node;
}

bool SpaceSectorLLRBT::isRed(Sector* node) {
    if (node == nullptr) {
        return false;
    }
    return node->color == RED;
}

Sector* SpaceSectorLLRBT::rotateLeft(Sector* node) {
    Sector* temp = node->right;
    node->right = temp->left;
    temp->left = node;
    temp->color = node->color;
    node->color = RED;

    return temp;
}

Sector* SpaceSectorLLRBT::rotateRight(Sector* node) {
    Sector* temp = node->left;
    node->left = temp->right;
    temp->right = node;
    temp->color = node->color;
    node->color = RED;

    return temp;
}

void SpaceSectorLLRBT::flipColors(Sector* node) {
    node->color = RED;
    node->left->color = BLACK;
    node->right->color = BLACK;
}

bool SpaceSectorLLRBT::getPath(Sector* root, const std::string& sector_code, std::vector<Sector*>& path){
    if (root == nullptr) {
        return false;
    }

    path.push_back(root);

    // path is found
    if (root->sector_code == sector_code) {
        return true;
    }

    // Check in left subtree
    if (getPath(root->left, sector_code, path)) {
        return true;
    }

    // Check in right subtree
    if (getPath(root->right, sector_code, path)) {
        return true;
    }

    path.pop_back();
    return false;
}


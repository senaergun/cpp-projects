#ifndef SPACESECTORLLRBT_H
#define SPACESECTORLLRBT_H

#include "Sector.h"
#include <iostream>
#include <fstream>  
#include <sstream>
#include <vector>
#include <queue>
#include <string>

class SpaceSectorLLRBT {
public:
    Sector* root;
    SpaceSectorLLRBT();
    ~SpaceSectorLLRBT();
    void readSectorsFromFile(const std::string& filename);
    void insertSectorByCoordinates(int x, int y, int z);
    Sector *insertNode(Sector *node, int x, int y, int z, Sector* parent);
    bool isRed(Sector* node);
    Sector* rotateLeft(Sector* node);
    Sector* rotateRight(Sector* node);
    void flipColors(Sector* node);
    void displaySectorsInOrder();
    void displaySectorsPreOrder();
    void displaySectorsPostOrder();
    void displayInOrder(Sector* node);
    void displayPreOrder(Sector* node);
    void displayPostOrder(Sector* node);
    void deleteTree(Sector* node);
    std::vector<Sector*> getStellarPath(const std::string& sector_code);
    bool getPath(Sector* root, const std::string& sector_code, std::vector<Sector*>& path);
    void printStellarPath(const std::vector<Sector*>& path);
};

#endif // SPACESECTORLLRBT_H

#include <iomanip>
#include "SpaceSectorBST.h"

using namespace std;

SpaceSectorBST::SpaceSectorBST() : root(nullptr) {}

SpaceSectorBST::~SpaceSectorBST() {
    // Free any dynamically allocated memory in this class.
    deleteTree(root);
}

void SpaceSectorBST::readSectorsFromFile(const std::string& filename) {
    // TODO: read the sectors from the input file and insert them into the BST sector map
    // according to the given comparison critera based on the sector coordinates.
    ifstream inputFile(filename);
    if (inputFile.is_open()) {
        string line = "";
        while (getline(inputFile, line)) {
            if (line != "X,Y,Z") {
                stringstream lineStream(line);
                string coordinate = "";
                int x, y, z;

                getline(lineStream, coordinate, ',');
                x = stringToInteger(coordinate);
                getline(lineStream, coordinate, ',');
                y = stringToInteger(coordinate);
                getline(lineStream, coordinate, ',');
                z = stringToInteger(coordinate);


                insertSectorByCoordinates(x, y, z);
            }
        }
        inputFile.close();
    }
}

void SpaceSectorBST::insertSectorByCoordinates(int x, int y, int z) {
    // Instantiate and insert a new sector into the space sector BST map according to the 
    // coordinates-based comparison criteria.
    root = insertNode(root, x, y, z);
}

void SpaceSectorBST::deleteSector(const std::string& sector_code) {
    // TODO: Delete the sector given by its sector_code from the BST.
    Sector *nodeToBeDeleted = findSector(root, sector_code);
    if (nodeToBeDeleted != nullptr) deleteItem(root, sector_code,nodeToBeDeleted->x, nodeToBeDeleted->y, nodeToBeDeleted->z);
}

void SpaceSectorBST::displaySectorsInOrder() {
    // TODO: Traverse the space sector BST map in-order and print the sectors 
    // to STDOUT in the given format.
    cout << "Space sectors inorder traversal:" << endl;
    displayInOrder(root);
    cout << endl;
}

void SpaceSectorBST::displaySectorsPreOrder() {
    // TODO: Traverse the space sector BST map in pre-order traversal and print 
    // the sectors to STDOUT in the given format.
    cout << "Space sectors preorder traversal:" << endl;
    displayPreOrder(root);
    cout << endl;
}

void SpaceSectorBST::displaySectorsPostOrder() {
    // TODO: Traverse the space sector BST map in post-order traversal and print 
    // the sectors to STDOUT in the given format.
    cout << "Space sectors postorder traversal:" << endl;
    displayPostOrder(root);
    cout << endl;
}

std::vector<Sector*> SpaceSectorBST::getStellarPath(const std::string& sector_code) {
    std::vector<Sector*> path;

    // TODO: Find the path from the Earth to the destination sector given by its
    // sector_code, and return a vector of pointers to the Sector nodes that are on
    // the path. Make sure that there are no duplicate Sector nodes in the path!
    if(getPath(root, sector_code, path))
        return path;
    else{
        path.clear();
        return path;
    }


}

void SpaceSectorBST::printStellarPath(const std::vector<Sector*>& path) {
    // TODO: Print the stellar path obtained from the getStellarPath() function 
    // to STDOUT in the given format.
    if(path.empty()){
        cout << "A path to Dr. Elara could not be found.";
    }
    else{
        cout << "The stellar path to Dr. Elara: " ;

        cout << path[0]->sector_code;

        for (size_t i = 1; i < path.size(); ++i) {
            cout << "->" << path[i]->sector_code;
        }
    }

    cout << endl;
}

Sector *SpaceSectorBST::insertNode(Sector *node, int x, int y, int z) {
    if (node == nullptr) {
        Sector* newNode = new Sector(x, y, z);
        return newNode;
    }

    if (x < node->x) {
        node->left = insertNode(node->left, x, y, z);
    } else if (x > node->x) {
        node->right = insertNode(node->right, x, y, z);
    } else {
        if (y < node->y) {
            node->left = insertNode(node->left, x, y, z);
        } else if (y > node->y) {
            node->right = insertNode(node->right, x, y, z);
        } else {
            if (z < node->z) {
                node->left = insertNode(node->left, x, y, z);
            } else if (z > node->z) {
                node->right = insertNode(node->right, x, y, z);
            }

        }
    }

    return node;
}

void SpaceSectorBST::displayInOrder(Sector* node) {
    if (node == nullptr) {
        return;
    }

    displayInOrder(node->left);
    cout << node->sector_code  << endl;
    displayInOrder(node->right);
}

void SpaceSectorBST::displayPreOrder(Sector* node) {
    if (node == nullptr) {
        return;
    }

    cout << node->sector_code  << endl;
    displayPreOrder(node->left);
    displayPreOrder(node->right);
}

void SpaceSectorBST::displayPostOrder(Sector* node) {
    if (node == nullptr) {
        return;
    }

    displayPostOrder(node->left);
    displayPostOrder(node->right);
    cout << node->sector_code  << endl;
}

void SpaceSectorBST::deleteTree(Sector* node) {
    if (node != nullptr) {
        deleteTree(node->left);
        deleteTree(node->right);
        delete node;
        node = nullptr;
    }
}

void SpaceSectorBST::deleteItem(Sector* &node, const string &sector_code, int x, int y, int z) {
    if (node == nullptr){
        return;
    }
    else if (sector_code == node->sector_code ){
        deleteNodeItem(node, x, y, z);
    }
    else if(x < node->x || (x == node->x && y < node->y) || (x == node->x && y == node->y && z < node->z)){
        deleteItem(node->left, sector_code, x, y, z);
    }
    else{
        deleteItem(node->right, sector_code, x, y, z);
    }
}

void SpaceSectorBST::deleteNodeItem(Sector *&node, int x, int y, int z) {
    Sector* delPtr;
    string newSectorCode;

    // deletion for a leaf
    if ( (node->left == nullptr) && (node->right == nullptr)) {
        delete node;
        node = nullptr;
    }
    // deletion for a node which has only right child
    else if (node->left == nullptr){
        delPtr = node;
        node = node->right;
        delPtr->right = nullptr;
        delete delPtr;
    }
    // deletion for a node which has only left child
    else if (node->right == nullptr){
        delPtr = node;
        node = node->left;
        delPtr-> left = nullptr;
        delete delPtr;
    }
    // deletion for a node which has two children
    else{
        findInorderSuccessor(node->right, newSectorCode, x, y, z);
        node->sector_code = newSectorCode;
        node->x = x;
        node->y = y;
        node->z = z;
        node->distance_from_earth = sqrt(pow(x, 2) + pow(y, 2) + pow(z, 2));
    }
}


void SpaceSectorBST::findInorderSuccessor(Sector *&node, string &sector_code, int &x, int &y, int &z){
    if (node->left == nullptr) {
        sector_code = node->sector_code;
        x = node->x;
        y = node->y;
        z = node->z;
        Sector *delPtr = node;
        node = node->right;
        delPtr->right = nullptr;
        delete delPtr;
    }
    else
        findInorderSuccessor(node->left, sector_code, x, y, z);
}

bool SpaceSectorBST::getPath(Sector* root, const std::string& sector_code, std::vector<Sector*>& path){
    if (root == nullptr) {
        return false;
    }

    path.push_back(root);

    // path is found
    if (root->sector_code == sector_code) {
        return true;
    }

    // Check in left subtree
    if (getPath(root->left, sector_code, path)) {
        return true;
    }

    // Check in right subtree
    if (getPath(root->right, sector_code, path)) {
        return true;
    }

    path.pop_back();
    return false;
}

Sector* SpaceSectorBST::findSector(Sector* node, string sectorCode) {
    if (node == nullptr) {
        return nullptr;
    }

    if (node->sector_code == sectorCode) {
        return node;
    }

    Sector* leftResult = findSector(node->left, sectorCode);
    if (leftResult != nullptr) {
        return leftResult;
    }

    Sector* rightResult = findSector(node->right, sectorCode);
    if (rightResult != nullptr) {
        return rightResult;
    }

    return nullptr;
}

int SpaceSectorBST::stringToInteger(const std::string& str) {
    int result = 0;
    int sign = 1;
    int i = 0;

    if (str[0] == '-') {
        sign = -1;
        i++;
    }

    for (; i < str.length(); ++i) {
        if (str[i] >= '0' && str[i] <= '9') {
            result = result * 10 + (str[i] - '0');
        } else {
            break;
        }
    }

    return result * sign;
}

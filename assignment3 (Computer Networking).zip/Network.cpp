#include "Network.h"

Network::Network() {

}

void Network::process_commands(vector<Client> &clients, vector<string> &commands, int message_limit,
                      const string &sender_port, const string &receiver_port) {
    // TODO: Execute the commands given as a vector of strings while utilizing the remaining arguments.
    /* Don't use any static variables, assume this method will be called over and over during testing.
     Don't forget to update the necessary member variables after processing each command. For example,
     after the MESSAGE command, the outgoing queue of the sender must have the expected frames ready to send. */
    
    for (string command : commands){
        string commandString(command.size() + 9, '-');
        vector<string> words = splitString(command);
        string firstWordOfCommand = words[0];

        if (firstWordOfCommand == "MESSAGE"){
            string sender_ID = words[1];
            string receiver_ID = words[2];
            string message = getTextBetweenHashtags(command);

            int frameNum = 0;
            if (message.size() % message_limit == 0){
                frameNum = (int(message.size())/int(message_limit));
            }else{
                frameNum = (int(message.size())/int(message_limit)) + 1;
            }



            // Find the sender client from its ID
            Client* senderClient = nullptr;
            for (Client &client: clients){
                if ( sender_ID == client.client_id){
                    senderClient = &client;
                    break;
                }
            }

            // Find the receiver client from its ID
            Client* receiverClient = nullptr;
            for (Client &client: clients){
                if ( receiver_ID == client.client_id){
                    receiverClient = &client;
                    break;
                }
            }

            Log new_log("", message, frameNum,0, sender_ID, receiver_ID, false, ActivityType::MESSAGE_SENT);
            senderClient->log_entries.push_back(new_log);

            // Find the receiver MAC address
            string receiver_mac = "";
            for (Client &client: clients){
                if ( senderClient->routing_table[receiverClient->client_id] == client.client_id){
                    receiver_mac = client.client_mac;
                    break;
                }
            }


            cout << commandString<<
                    "\nCommand: " << command << endl<<
                    commandString << endl <<
                    "Message to be sent: \"" << message << "\"\n\n";

            for (int i = 0; i < frameNum ; i ++){
                string chunk = "";
                if (message.substr(i*message_limit).length() < message_limit){
                   chunk = message.substr(i*message_limit);
                }
                else {
                    chunk = message.substr(i*message_limit, message_limit);
                }
                Packet *applicationLayerPacket = new ApplicationLayerPacket(0, sender_ID, receiver_ID, chunk);
                Packet *transportLayerPacket = new TransportLayerPacket(1, sender_port, receiver_port);
                Packet *networkLayerPacket = new NetworkLayerPacket(2, senderClient->client_ip, receiverClient->client_ip);
                Packet *physicalLayerPacket = new PhysicalLayerPacket(3, senderClient->client_mac, receiver_mac);
                auto* appPacket = dynamic_cast<ApplicationLayerPacket*>(applicationLayerPacket);
                appPacket->numberOfHops = 0;
                appPacket->frameNum = i+1;

                stack<Packet*> frame;
                frame.push(applicationLayerPacket);
                frame.push(transportLayerPacket);
                frame.push(networkLayerPacket);
                frame.push(physicalLayerPacket);

                senderClient->outgoing_queue.push(frame);

                // PRINT
                cout << "Frame #" << appPacket->frameNum << "\n";
                physicalLayerPacket->print();
                networkLayerPacket->print();
                transportLayerPacket->print();
                applicationLayerPacket->print();
                cout << "Message chunk carried: \"" << chunk << "\"\n";
                cout << "Number of hops so far: " << appPacket->numberOfHops << endl;
                cout << "--------\n";

                dynamicPackets.push_back(applicationLayerPacket);
                dynamicPackets.push_back(transportLayerPacket);
                dynamicPackets.push_back(networkLayerPacket);
                dynamicPackets.push_back(physicalLayerPacket);
            }
        }
        else if (firstWordOfCommand == "SHOW_FRAME_INFO"){
            string client_ID = words[1];
            string queue_selection = words[2];
            int frame_number = stoi(words[3]);

            Client* client = nullptr;
            for (Client& c : clients) {
                if (c.client_id == client_ID) {
                    client = &c;
                    break;
                }
            }

            cout << commandString<<
                 "\nCommand: " << command << endl<<
                 commandString << endl ;

            if (queue_selection == "out") {
                if (frame_number <= client->outgoing_queue.size()) {
                    cout << "Current Frame #" << frame_number << " on the outgoing queue of client " << client_ID << "\n";

                    queue<stack<Packet*>> tempQueue = client->outgoing_queue;

                    int framesInspected = 0;
                    while (!tempQueue.empty()){
                        stack<Packet*> frame = tempQueue.front();
                        tempQueue.pop();
                        framesInspected++;

                        if (framesInspected == frame_number) {
                            vector<Packet*> packetOrder;

                            // Iterate through the packets in the frame
                            for (int i = 0; i < 4; i++) {
                                stack<Packet*> packetStack = frame;
                                vector<Packet*> tempPacketOrder;

                                while (!packetStack.empty()) {
                                    tempPacketOrder.push_back(packetStack.top());
                                    packetStack.pop();
                                }

                                // Store packets in reverse order to print from bottom to top
                                for (int j = tempPacketOrder.size() - 1; j >= 0; --j) {
                                    packetOrder.push_back(tempPacketOrder[j]);
                                }
                            }

                            // Print packets in reverse order (from bottom to top)
                            int numberOfHops = 0;
                            for (int i =0 ; i < 4 ; i++) {
                                Packet* packet = packetOrder[i];
                                if (ApplicationLayerPacket* appPacket = dynamic_cast<ApplicationLayerPacket*>(packet)) {
                                    cout << "Carried Message: \"" << appPacket->message_data << "\"" <<endl;
                                    cout << "Layer 0 info: ";
                                    appPacket->print();
                                    numberOfHops = appPacket->numberOfHops;
                                } else if (TransportLayerPacket* transPacket = dynamic_cast<TransportLayerPacket*>(packet)) {
                                    cout << "Layer 1 info: ";
                                    transPacket->print();
                                } else if (NetworkLayerPacket* networkPacket = dynamic_cast<NetworkLayerPacket*>(packet)) {
                                    cout << "Layer 2 info: ";
                                    networkPacket->print();
                                } else if (PhysicalLayerPacket* physicalPacket = dynamic_cast<PhysicalLayerPacket*>(packet)) {
                                    cout << "Layer 3 info: ";
                                    physicalPacket->print();
                                }
                            }
                            cout << "Number of hops so far: " << numberOfHops << endl;
                            break;
                        }
                    }
                }
                else{
                    cout << "No such frame.\n";

                }
            }
            else if(queue_selection == "in") {
                if (frame_number <= client->incoming_queue.size()) {
                    cout << "Current Frame #" << frame_number << " on the incoming queue of client " << client_ID << "\n";

                    queue<stack<Packet*>> tempQueue = client->incoming_queue;

                    int framesInspected = 0;
                    while (!tempQueue.empty()){
                        stack<Packet*> frame = tempQueue.front();
                        tempQueue.pop();
                        framesInspected++;

                        if (framesInspected == frame_number) {
                            vector<Packet*> packetOrder;

                            // Iterate through the packets in the frame
                            for (int i = 0; i < 4; i++) {
                                stack<Packet*> packetStack = frame;
                                vector<Packet*> tempPacketOrder;

                                while (!packetStack.empty()) {
                                    tempPacketOrder.push_back(packetStack.top());
                                    packetStack.pop();
                                }

                                // Store packets in reverse order to print from bottom to top
                                for (int j = tempPacketOrder.size() - 1; j >= 0; --j) {
                                    packetOrder.push_back(tempPacketOrder[j]);
                                }
                            }

                            // Print packets in reverse order (from bottom to top)
                            int numberOfHops = 0;
                            for (int i =0 ; i < 4 ; i++) {
                                Packet* packet = packetOrder[i];
                                if (ApplicationLayerPacket* appPacket = dynamic_cast<ApplicationLayerPacket*>(packet)) {
                                    cout << "Carried Message: \"" << appPacket->message_data <<"\"" << endl;
                                    cout << "Layer 0 info: ";
                                    appPacket->print();
                                    numberOfHops = appPacket->numberOfHops;
                                } else if (TransportLayerPacket* transPacket = dynamic_cast<TransportLayerPacket*>(packet)) {
                                    cout << "Layer 1 info: ";
                                    transPacket->print();
                                } else if (NetworkLayerPacket* networkPacket = dynamic_cast<NetworkLayerPacket*>(packet)) {
                                    cout << "Layer 2 info: ";
                                    networkPacket->print();
                                } else if (PhysicalLayerPacket* physicalPacket = dynamic_cast<PhysicalLayerPacket*>(packet)) {
                                    cout << "Layer 3 info: ";
                                    physicalPacket->print();
                                }
                            }
                            cout << "Number of hops so far: " << numberOfHops << endl;
                            break;
                        }
                    }
                }
                else{
                    cout << "No such frame.\n";

                }
            }
        }
        else if (firstWordOfCommand == "SHOW_Q_INFO"){
            string client_ID = words[1];
            string queue_selection = words[2];

            // Find the client by ID
            Client* client = nullptr;
            for (Client& c : clients) {
                if (c.client_id == client_ID) {
                    client = &c;
                    break;
                }
            }
            if (queue_selection == "out") {
                cout << commandString<<
                     "\nCommand: " << command << endl<<
                     commandString << endl <<
                     "Client " << client_ID << " Outgoing Queue Status\n"
                                               "Current total number of frames: " << client->outgoing_queue.size() << "\n";
            } else if (queue_selection == "in") {
                cout << commandString<<
                     "\nCommand: " << command << endl<<
                     commandString << endl <<
                        "Client " << client_ID << " Incoming Queue Status\n"
                        "Current total number of frames: " << client->incoming_queue.size() << "\n";
            }
        }
        else if (firstWordOfCommand == "SEND"){
            cout << commandString<<
                 "\nCommand: " << command << endl<<
                 commandString << endl ;


            for (Client &senderClient : clients){

                while (!senderClient.outgoing_queue.empty()){

                    for (Log &log: senderClient.log_entries){
                        log.success_status = true;
                        log.activity_type = ActivityType::MESSAGE_SENT;
                    }

                    stack<Packet*> frame = senderClient.outgoing_queue.front();
                    senderClient.outgoing_queue.pop();

                    stack<Packet*> tempFrame = frame;
                    // Reach bottom packet
                    while (tempFrame.size() > 1) {
                        tempFrame.pop();
                    }

                    auto* appPacket = dynamic_cast<ApplicationLayerPacket*>(tempFrame.top());
                    string receiver_ID = appPacket->receiver_ID;

                    string receiver_mac = "";
                    for (Client &client: clients){
                        if ( senderClient.routing_table[receiver_ID] == client.client_id){
                            receiver_mac = client.client_mac;
                            break;
                        }
                    }

                    for (Client &receiverClient : clients){
                        if (receiverClient.client_mac == receiver_mac){
                            receiverClient.incoming_queue.push(frame);
                            stack<Packet*> tempFrame2 = frame;
                            cout << "Client " << senderClient.client_id << " sending frame #" << appPacket->frameNum  << " to client " << receiverClient.client_id << "\n";
                            auto* physicalLayerPacket = dynamic_cast<PhysicalLayerPacket*>(tempFrame2.top());
                            physicalLayerPacket->print();
                            tempFrame2.pop();

                            auto* networkLayerPacket = dynamic_cast<NetworkLayerPacket*>(tempFrame2.top());
                            networkLayerPacket->print();
                            tempFrame2.pop();

                            auto* transportLayerPacket = dynamic_cast<TransportLayerPacket*>(tempFrame2.top());
                            transportLayerPacket->print();
                            tempFrame2.pop();

                            auto* applicationLayerPacket = dynamic_cast<ApplicationLayerPacket*>(tempFrame2.top());
                            applicationLayerPacket->print();
                            cout << "Message chunk carried: \"" << applicationLayerPacket->message_data <<"\"" << endl;
                            tempFrame2.pop();
                            applicationLayerPacket->numberOfHops += 1;

                            cout <<"Number of hops so far: " << applicationLayerPacket->numberOfHops << endl <<
                                   "--------\n";
                        }
                    }
                }
            }
        }
        else if (firstWordOfCommand == "RECEIVE"){
            cout << commandString<<
                 "\nCommand: " << command << endl<<
                 commandString << endl ;

            for (Client &receiverClient : clients){
                string message = "";
                while (!receiverClient.incoming_queue.empty()){
                    stack<Packet*> frame = receiverClient.incoming_queue.front();
                    receiverClient.incoming_queue.pop();

                    stack<Packet*> tempFrame = frame;
                    auto* physicalLayerPacket = dynamic_cast<PhysicalLayerPacket*>(frame.top());
                    string receiver_mac = physicalLayerPacket->receiver_MAC_address;
                    string sender_mac = physicalLayerPacket->sender_MAC_address;

                    string sender_ID = "";
                    for (Client &client: clients){
                        if ( sender_mac == client.client_mac){
                            sender_ID = client.client_id;
                            break;
                        }
                    }

                    // Reach bottom packet
                    while (tempFrame.size() > 1) {
                        tempFrame.pop();
                    }

                    auto* appPacket = dynamic_cast<ApplicationLayerPacket*>(tempFrame.top());
                    string receiver_ID = appPacket->receiver_ID;
                    string original_sender_ID = appPacket->sender_ID;
                    int frameNum = appPacket->frameNum;

                    auto now = std::chrono::system_clock::now();
                    std::time_t now_c = std::chrono::system_clock::to_time_t(now);
                    std::tm tm_now = *std::localtime(&now_c);
                    std::stringstream ss;
                    ss << std::put_time(&tm_now, "%Y-%m-%d %H:%M:%S");
                    std::string str_time=ss.str();


                    if (receiver_ID == receiverClient.client_id){
                        // message has reached final destination


                        for (Log &log: receiverClient.log_entries){
                            log.activity_type = ActivityType::MESSAGE_RECEIVED;
                            log.success_status = true;
                            log.timestamp = str_time;
                        }

                        cout <<"Client " <<receiver_ID << " receiving frame #" <<frameNum <<" from client " <<sender_ID<<", originating from client " << original_sender_ID << endl;
                        auto * physicalPacket = dynamic_cast<PhysicalLayerPacket*>(frame.top());
                        physicalPacket->print();
                        frame.pop();

                        auto *networkPacket = dynamic_cast<NetworkLayerPacket*>(frame.top());
                        networkPacket->print();
                        frame.pop();

                        auto * transPacket = dynamic_cast<TransportLayerPacket*>(frame.top());
                        transPacket->print();
                        frame.pop();

                        auto * applicationPacket = dynamic_cast<ApplicationLayerPacket*>(frame.top());
                        applicationPacket->print();
                        frame.pop();

                        cout <<"Message chunk carried: \"" << applicationPacket->message_data <<"\"" << endl;
                        cout <<"Number of hops so far: " << applicationPacket->numberOfHops << endl;
                        cout <<"--------\n";

                        message.append(applicationPacket->message_data);


                        if(applicationPacket->message_data.back() == '.' || applicationPacket->message_data.back() == '!'|| applicationPacket->message_data.back() == '?'){
                            cout << "Client " << receiver_ID <<" received the message \"" <<message << "\" from client " << original_sender_ID <<".\n" ;
                            cout <<"--------\n";
                            Log log(str_time, message,applicationPacket->frameNum,applicationPacket->numberOfHops, original_sender_ID, receiver_ID,true, ActivityType::MESSAGE_RECEIVED);
                            receiverClient.log_entries.push_back(log);
                            message.clear();
                        }
                    }
                    else{
                        auto * physicalPacket = dynamic_cast<PhysicalLayerPacket*>(frame.top());
                                                string new_receiver_mac_address ="";
                        bool clientPresent = false;
                        for (Client &client: clients){
                            if ( receiverClient.routing_table[receiver_ID] == client.client_id){
                                new_receiver_mac_address = client.client_mac;
                                clientPresent = true;
                                break;
                            }
                        }

                        if (clientPresent){
                            // hop
                            if(frameNum == 1)
                                cout << "Client " << receiverClient.client_id <<" receiving a message from client " << sender_ID<<", but intended for client " << receiver_ID<< ". Forwarding...\n";

                            physicalPacket->receiver_MAC_address = new_receiver_mac_address;
                            physicalPacket->sender_MAC_address = receiver_mac;
                            receiverClient.outgoing_queue.push(frame);
                            message.append(appPacket->message_data);
                            cout << "Frame #" << frameNum<<" MAC address change: New sender MAC "<< receiver_mac<<", new receiver MAC " << new_receiver_mac_address << endl;
                            if(appPacket->message_data.back() == '.' || appPacket->message_data.back() == '!'|| appPacket->message_data.back() == '?'){
                                Log log(str_time, message,appPacket->frameNum,appPacket->numberOfHops,appPacket->sender_ID, appPacket->receiver_ID,true,ActivityType::MESSAGE_FORWARDED);
                                receiverClient.log_entries.push_back(log),
                                cout << "--------\n";
                                message.clear();
                            }

                        }
                        else{
                            // drop
                            cout <<"Client " << receiverClient.client_id <<" receiving frame #" <<frameNum<<" from client " << sender_ID<<", but intended for client " << receiver_ID<< ". Forwarding...\n"
                                "\nError: Unreachable destination. Packets are dropped after " <<appPacket->numberOfHops << " hops!\n";
                            message.append(appPacket->message_data);
                            if (appPacket->message_data.back() == '.' || appPacket->message_data.back() == '!'|| appPacket->message_data.back() == '?' ){
                                cout << "--------\n";
                                Log log(str_time,message,appPacket->numberOfHops,appPacket->frameNum,appPacket->sender_ID,appPacket->receiver_ID,false,ActivityType::MESSAGE_DROPPED);
                                receiverClient.log_entries.push_back(log);
                                message.clear();
                            }
                        }
                    }
                }
            }
        }
        else if(firstWordOfCommand == "PRINT_LOG"){
            cout << commandString<<
                 "\nCommand: " << command << endl<<
                 commandString << endl;

            Client *requested_client = nullptr;
            string requested_client_ID = words[1];
            for (Client &client: clients){
                if ( requested_client_ID == client.client_id){
                    requested_client = &client;
                    break;
                }
            }
            cout << "Client " << requested_client_ID << " Logs:" << endl;

            int logEntryCount = 0;

            for (auto &log : requested_client->log_entries){
                logEntryCount++;
                cout << "--------------" << endl;
                cout << "Log Entry #" << logEntryCount << ":" << endl;
                ActivityType activityType = log.activity_type;
                string activity= "";
                switch (activityType) {
                    case ActivityType::MESSAGE_RECEIVED:
                        activity = " Message Received";
                        break;
                    case ActivityType::MESSAGE_FORWARDED:
                        activity = "Message Forwarded";
                        break;
                    case ActivityType::MESSAGE_SENT:
                        activity = "Message Sent";
                        break;
                    case ActivityType::MESSAGE_DROPPED:
                        activity = "Message Dropped";
                        break;
                }
                cout << "Activity: " << activity << endl;
                cout << "Timestamp: " << log.timestamp << endl;
                cout << "Number of frames: " << log.number_of_frames << endl;
                cout << "Number of hops: " << log.number_of_hops << endl;
                cout << "Sender ID: " << log.sender_id << endl;
                cout << "Receiver ID: " << log.receiver_id << endl;
                cout << "Success: " << (log.success_status ? "Yes" : "No") << endl;

                if (activity == "Message Received" || activity == "Message Forwarded") {
                    cout << "Message: \"" << log.message_content << "\"" << endl;
                }

            }
        }
        else{
            cout << commandString<<
                 "\nCommand: " << command << endl<<
                 commandString << endl<<
                 "Invalid command.\n";
        }
    }
}

vector<Client> Network::read_clients(const string &filename) {
    vector<Client> clients;
    // TODO: Read clients from the given input file and return a vector of Client instances.

    ifstream inputFile(filename);

    int numClients = 0;
    inputFile >> numClients;

    for (int i = 0; i < numClients; ++i) {
        string id, ip, mac;
        inputFile >> id >> ip >> mac;

        // Create a new client instance and add it to the vector
        Client newClient(id, ip, mac);
        clients.push_back(newClient);
    }
    inputFile.close();
    return clients;
}

void Network::read_routing_tables(vector<Client> &clients, const string &filename) {
    // TODO: Read the routing tables from the given input file and populate the clients' routing_table member variable.

    ifstream inputFile(filename);

    string line;
    int clientIndex = 0;
    while (std::getline(inputFile, line)){
        if (line == "-"){
            clientIndex++;
            continue;
        }

        istringstream iss(line);
        string intendedDestination, next_hop;
        iss >> intendedDestination >> next_hop;

        if (clientIndex >= clients.size()){
            cout << "Routing information exceeds the number of clients." << std::endl;
            break;
        }

        clients[clientIndex].routing_table[intendedDestination] = next_hop;
    }
    inputFile.close();
}

// Returns a list of token lists for each command
vector<string> Network::read_commands(const string &filename) {
    vector<string> commands;
    // TODO: Read commands from the given input file and return them as a vector of strings.

    ifstream file(filename);

    string line;
    int numberCommands = 0;
    getline(file, line);
    istringstream iss(line);
    iss >> numberCommands;

    while (std::getline(file, line)) {
        commands.push_back(line);
    }

    file.close();
    return commands;
}

vector<string> Network::splitString(const std::string& str) {
    std::istringstream iss(str);
    std::vector<std::string> tokens;
    std::string token;

    while (std::getline(iss, token, ' ')) {
        tokens.push_back(token);
    }

    return tokens;
}

string Network::getTextBetweenHashtags(const std::string& str) {
    size_t startPos = str.find('#');
    size_t endPos = str.find('#', startPos + 1);

    if (startPos != string::npos && endPos != string::npos && endPos > startPos) {
        return str.substr(startPos + 1, endPos - startPos - 1);
    }

    return "";
}

Network::~Network() {
    // TODO: Free any dynamically allocated memory if necessary.
    for (Packet* packet : dynamicPackets) {
        delete packet;
    }
    dynamicPackets.clear();
}

#include <algorithm>
#include "GameController.h"
#include <fstream>
#include <chrono>
#include <sstream>


bool GameController::play(BlockFall& game, const string& commands_file){

    // TODO: Implement the gameplay here while reading the commands from the input file given as the 3rd command-line
    //       argument. The return value represents if the gameplay was successful or not: false if game over,
    //       true otherwise.
    std::ifstream leaderboard(game.leaderboard_file_name); // Replace "input.txt" with your file name

    if (leaderboard.is_open()) {
        std::string newLine;
        while (std::getline(leaderboard, newLine)) {
            std::istringstream iss(newLine);
            std::string firstWord;
            iss >> firstWord;

            // Check if there's at least one word on the line
            if (!firstWord.empty()) {
                highScore = stoul(firstWord);
                break;
            }
        }

        leaderboard.close();
    }




    bool gameOver = false;
    bool gameFinished = false;


    std::ifstream inputFile(commands_file);
    if (!inputFile.is_open()) {
        std::cout << "Error opening the file!" << std::endl;
        exit(-1);
    }

    game.active_rotation = game.initial_block;

    // Insert initial block to grid
    handleMovement(game.grid, game.initial_block, pair<int,int> {0,0},game.initial_block->shape.size(),game.initial_block->shape[0].size());

    std::string line;
    while (std::getline(inputFile, line)){

        if (line =="PRINT_GRID") {
            cout<< "Score: " << game.current_score << endl;
            cout<< "High Score: " << highScore<< endl ;
            printGrid(game.grid);
        }

        else if(line == "ROTATE_RIGHT"){
            Block* rotatedBlock = game.active_rotation->right_rotation;
            rotatedBlock->topLeftCell = {game.active_rotation->topLeftCell};
            int newHeight = rotatedBlock->shape.size();
            int newWidth = rotatedBlock->shape[0].size();

            removeBlock(game.grid, game.active_rotation); // Remove active block to check grid availability

            if (isPossible(game.grid, rotatedBlock,game.active_rotation->topLeftCell, newHeight, newWidth)){
                handleMovement(game.grid, rotatedBlock, game.active_rotation->topLeftCell, rotatedBlock->shape.size(), rotatedBlock->shape[0].size() );
                game.active_rotation = rotatedBlock;
            }
            else{
                // Put block back if it is not possible to rotate
                handleMovement(game.grid, game.active_rotation, game.active_rotation->topLeftCell, game.active_rotation->shape.size(), game.active_rotation->shape[0].size());
            }
        }

        else if(line == "ROTATE_LEFT"){
            Block* rotatedBlock = game.active_rotation->left_rotation;
            rotatedBlock->topLeftCell = {game.active_rotation->topLeftCell};
            int newHeight = rotatedBlock->shape.size();
            int newWidth = rotatedBlock->shape[0].size();

            removeBlock(game.grid, game.active_rotation); // Remove active block to check grid availability

            if (isPossible(game.grid, rotatedBlock,game.active_rotation->topLeftCell, newHeight, newWidth)){
                handleMovement(game.grid, rotatedBlock, game.active_rotation->topLeftCell, rotatedBlock->shape.size(), rotatedBlock->shape[0].size() );
                game.active_rotation = rotatedBlock;
            }
            else{
                // Put block back if it is not possible to rotate
                handleMovement(game.grid, game.active_rotation, game.active_rotation->topLeftCell, game.active_rotation->shape.size(), game.active_rotation->shape[0].size());
            }
        }

        else if(line == "MOVE_RIGHT"){

            int height = game.active_rotation->shape.size();
            int width = game.active_rotation->shape[0].size();

            removeBlock(game.grid, game.active_rotation); // Remove active block to check grid availability
            game.active_rotation->topLeftCell.second = game.active_rotation->topLeftCell.second + 1; // Add 1 to column idx of top left cell;

            if (isPossible(game.grid, game.active_rotation,game.active_rotation->topLeftCell, height, width)){
                handleMovement(game.grid, game.active_rotation, game.active_rotation->topLeftCell, game.active_rotation->shape.size(), game.active_rotation->shape[0].size() );
            }
            else{
                // Put block back if it is not possible to move
                game.active_rotation->topLeftCell.second = game.active_rotation->topLeftCell.second-1; // Restore index
                handleMovement(game.grid, game.active_rotation, game.active_rotation->topLeftCell, game.active_rotation->shape.size(), game.active_rotation->shape[0].size());
            }
        }

        else if(line == "MOVE_LEFT"){

            int height = game.active_rotation->shape.size();
            int width = game.active_rotation->shape[0].size();

            removeBlock(game.grid, game.active_rotation); // Remove active block to check grid availability
            game.active_rotation->topLeftCell.second = game.active_rotation->topLeftCell.second - 1; // Subtract 1 from column idx of top left cell;

            if (isPossible(game.grid, game.active_rotation,game.active_rotation->topLeftCell, height, width)){
                handleMovement(game.grid, game.active_rotation, game.active_rotation->topLeftCell, game.active_rotation->shape.size(), game.active_rotation->shape[0].size() );
            }
            else{
                // Put block back if it is not possible to move
                game.active_rotation->topLeftCell.second = game.active_rotation->topLeftCell.second+1; // Restore index
                handleMovement(game.grid, game.active_rotation, game.active_rotation->topLeftCell, game.active_rotation->shape.size(), game.active_rotation->shape[0].size());
            }
        }

        else if(line == "DROP"){
            removeBlock(game.grid, game.active_rotation); // Remove active block to check grid availability

            if (!game.gravity_mode_on){
                pair<int,int> newTopLeft = game.active_rotation->topLeftCell;
                newTopLeft.first = newTopLeft.first + 1;

                for(int i = newTopLeft.first; i <= game.rows; i++){
                    if (isPossible(game.grid, game.active_rotation, newTopLeft, game.active_rotation->shape.size(), game.active_rotation->shape[0].size())){

                        game.active_rotation->fallingDistance += 1;
                        handleMovement(game.grid, game.active_rotation, newTopLeft,game.active_rotation->shape.size(), game.active_rotation->shape[0].size());
                        game.active_rotation->topLeftCell = newTopLeft;
                        removeBlock(game.grid, game.active_rotation);
                        newTopLeft.first = newTopLeft.first + 1;
                    }
                    else{
                        handleMovement(game.grid, game.active_rotation, game.active_rotation->topLeftCell, game.active_rotation->shape.size(), game.active_rotation->shape[0].size());
                    }
                }
                int scoreWillBeAdded = calculateOccupiedCell(game.active_rotation->shape)*game.active_rotation->fallingDistance;
                game.current_score = game.current_score + scoreWillBeAdded;
                highScore = max(game.current_score, (unsigned long)highScore);
            }
            else{
                int fallingDistance = {999};
                // Create a block for each column of active rotation
                for (int n = 0; n< game.active_rotation->shape[0].size(); n++){
                    Block blockObj;
                    blockObj.shape.resize(game.active_rotation->shape.size());
                    blockObj.topLeftCell.second = game.active_rotation->topLeftCell.second + n;
                    pair<int,int> newTopLeft = blockObj.topLeftCell;
                    newTopLeft.first = newTopLeft.first + 1;

                    for (int k = 0; k < game.active_rotation->shape.size(); k++) {
                        blockObj.shape[k].push_back(game.active_rotation->shape[k][n]) ;
                    }
                    // Check availability for each created piece
                    for(int i = newTopLeft.first; i <= game.rows+1; i++){
                        if (isPossible(game.grid, &blockObj, newTopLeft, blockObj.shape.size(), blockObj.shape[0].size())){
                            handleMovement(game.grid, &blockObj, newTopLeft,blockObj.shape.size(), blockObj.shape[0].size());

                            blockObj.topLeftCell = newTopLeft;
                            blockObj.fallingDistance += 1;
                            removeBlock(game.grid, &blockObj);
                            newTopLeft.first = newTopLeft.first + 1;

                        }
                        else{
                            handleMovement(game.grid, &blockObj, blockObj.topLeftCell, blockObj.shape.size(), blockObj.shape[0].size());
                        }
                    }
                    fallingDistance = min(fallingDistance,blockObj.fallingDistance);
                }
                int scoreWillBeAdded = calculateOccupiedCell(game.active_rotation->shape)*fallingDistance;
                game.current_score = game.current_score + scoreWillBeAdded;
                highScore = max(game.current_score, (unsigned long)highScore);

                for (int j = 0; j< game.cols; j++ ){
                    int occupiedCellInColumn{0};
                    for (int i  = 0; i<game.rows; i++){
                        if(game.grid[i][j] == 1)
                            occupiedCellInColumn += 1;
                    }
                    for (int gi = game.rows; gi > 0 ; gi--) {

                        if (occupiedCellInColumn > 0) {
                            game.grid[gi - 1][j] = 1;
                            occupiedCellInColumn--;
                        } else {
                            game.grid[gi - 1][j] = 0;
                        }

                    }
                }

            }

            // Check power up and cleared rows
            if(detectPowerUp(game.grid,game.power_up)){
                cout<<"Before clearing:"<< endl;
                printGrid(game.grid);
                game.current_score += 1000;
                highScore = max(game.current_score, (unsigned long)highScore);
                // Clear grid
                for (auto& row : game.grid) {
                    for (auto& element : row) {
                        if(element == 1){
                            game.current_score +=1;
                            element = 0;
                        }
                    }
                }
            }
            for (int i = game.grid.size(); i > 0; --i) {
                if (std::all_of(game.grid[i - 1].begin(), game.grid[i - 1].end(), [](int val){ return val != 0; })) {
                    cout<<"Before clearing:"<< endl;
                    printGrid(game.grid);
                }
            }

            for (int k = 0; k<= game.rows; k++ ){
                int clearedRows = clearCompletedRows(game.grid);
                if (clearedRows > 0) {
                    int scoreIncrease = clearedRows * game.grid[0].size(); // Bonus points calculation
                    game.current_score += scoreIncrease;
                    highScore = max(game.current_score, (unsigned long)highScore);
                }
            }

            if( game.active_rotation->next_block == nullptr || !isPossible(game.grid, game.active_rotation->next_block, pair<int,int> {0,0}, game.active_rotation->next_block->shape.size(), game.active_rotation->next_block->shape[0].size())){
                // Handle game over
                highScore = max(game.current_score, (unsigned long)highScore);

                if(game.active_rotation->next_block == nullptr){
                    cout<<"YOU WIN!\n"
                          "No more blocks.\n"
                          "Final grid and score:\n"<< endl;
                    gameFinished = true;
                    break;

                }
                else{
                    cout <<"GAME OVER!\n"
                           "Next block that couldn't fit:"<<endl;
                    for (const auto& row : game.active_rotation->next_block->shape) {
                        for (int num : row) {
                            if(num == 1){
                                std::cout << occupiedCellChar << " ";
                            }else{
                                std::cout << unoccupiedCellChar << " ";

                            }

                        }
                        std::cout << std::endl;
                    }
                    cout << "\nFinal grid and score:\n" << endl;
                    gameOver = true;
                    gameFinished = true;
                    break;
                }


            }else{
                // Update active block if game is not over
                game.active_rotation = game.active_rotation->next_block;
                handleMovement(game.grid, game.active_rotation, pair<int,int> {0,0}, game.active_rotation->shape.size(), game.active_rotation->shape[0].size());
            }
        }
        else if(line == "GRAVITY_SWITCH"){
            game.gravity_mode_on = !game.gravity_mode_on;
            if (game.gravity_mode_on){
                removeBlock(game.grid, game.active_rotation);
                for (int j = 0; j< game.cols; j++ ){
                    int occupiedCellInColumn{0};
                    for (int i  = 0; i<game.rows; i++){
                        if(game.grid[i][j] == 1)
                            occupiedCellInColumn += 1;
                    }
                    for (int gi = game.rows; gi > 0 ; gi--) {

                        if (occupiedCellInColumn > 0) {
                            game.grid[gi - 1][j] = 1;
                            occupiedCellInColumn--;
                        } else {
                            game.grid[gi - 1][j] = 0;
                        }

                    }
                }
                // Check power up and cleared rows
                if(detectPowerUp(game.grid,game.power_up)){
                    cout<<"Before clearing:"<< endl;
                    printGrid(game.grid);
                    game.current_score += 1000;
                    highScore = max(game.current_score, (unsigned long)highScore);
                    // Clear grid
                    for (auto& row : game.grid) {
                        for (auto& element : row) {
                            if(element == 1){
                                game.current_score +=1;
                                element = 0;
                            }
                        }
                    }
                }
                for (int i = game.grid.size() ; i > 0; --i) {
                    if (std::all_of(game.grid[i - 1].begin(), game.grid[i - 1].end(), [](int val){ return val != 0; })) {
                        cout<<"Before clearing:"<< endl;
                        printGrid(game.grid);
                    }
                }
                for (int k = 0; k<= game.rows; k++ ){
                    int clearedRows = clearCompletedRows(game.grid);
                    if (clearedRows > 0) {
                        int scoreIncrease = clearedRows * game.grid[0].size(); // Bonus points calculation
                        game.current_score += scoreIncrease;
                        highScore = max(game.current_score, (unsigned long)highScore);
                    }
                }
                handleMovement(game.grid, game.active_rotation, game.active_rotation->topLeftCell, game.active_rotation->shape.size(), game.active_rotation->shape[0].size());
            }


        }
        else{
            cout << "Unknown command: "<< line <<endl;
        }


    }
    if (!gameFinished){
        highScore = max(game.current_score, (unsigned long)highScore);
        removeBlock(game.grid, game.active_rotation);
        cout<<"GAME FINISHED!\n"
              "No more commands.\n"
              "Final grid and score:\n"<<endl;
    }
    // Handle game Over
    cout<< "Score: " << game.current_score << endl;
    cout<< "High Score: " << highScore << endl ;
    printGrid(game.grid);


    time_t time = getCurrentTime();
    LeaderboardEntry *newEntry = new LeaderboardEntry(game.current_score, time, game.player_name);
    game.leaderboard.insert_new_entry(newEntry);
    game.leaderboard.print_leaderboard();
    game.leaderboard.write_to_file(game.leaderboard_file_name);

    inputFile.close();


    if(gameOver){
        return false;
    }
    else{
        return true;
    }

}
std::time_t GameController::getCurrentTime() {
    return std::time(nullptr);
}

void GameController::printGrid(vector<vector<int>>& grid){
    for (const auto& row : grid) {
        for (int num : row) {
            if (num == 1)
                cout << occupiedCellChar;
            else
                cout << unoccupiedCellChar;
        }
        std::cout << std::endl;
    }
    std::cout << std:: endl;
}

bool GameController::isPossible(const vector<vector<int>>& grid,Block* block, std::pair<int,int> newTopLeft,int heightToBeChecked, int widthToBeChecked){

    // Check the bounds
    if(newTopLeft.first + heightToBeChecked > grid.size() || newTopLeft.first < 0 )
        return false;
    if (newTopLeft.second + widthToBeChecked > grid[0].size() || newTopLeft.second < 0)
        return false;


    // Check the occupied cells
    int rowIdx = 0;
    for (int i = newTopLeft.first; i < newTopLeft.first + heightToBeChecked; i++){
        int colIdx = 0;
        for (int j = newTopLeft.second; j < newTopLeft.second + widthToBeChecked; j++){
            if (block->shape[rowIdx][colIdx] == 1 && grid[i][j] == 1){
                return false;
            }
            colIdx++;
        }
        rowIdx++;
    }
    return true;
}

void GameController::handleMovement(vector<vector<int>>& grid, Block* block, std::pair<int,int> newTopLeft, int height, int width){
    int rowIdx = 0;
    for (int i = newTopLeft.first; i < newTopLeft.first + height; i++){
        int colIdx = 0;
        for (int j = newTopLeft.second; j < newTopLeft.second + width; j++){
            int value = block->shape[rowIdx][colIdx];
            if (value == 1)
                grid[i][j] = value;
            colIdx++;
        }
        rowIdx++;
    }
}

void GameController::removeBlock(vector<vector<int>>& grid, Block* block){
    int rowIdx = 0;
    for (int i = block->topLeftCell.first; i < block->topLeftCell.first + block->shape.size(); i++){
        int colIdx = 0;
        for (int j = block->topLeftCell.second; j < block->topLeftCell.second + block->shape[0].size(); j++){
            if (block->shape[rowIdx][colIdx] == 1)
                grid[i][j] = 0;
            colIdx++;
        }
        rowIdx++;
    }

}
bool GameController::detectPowerUp(const std::vector<std::vector<int>>& grid, const std::vector<std::vector<bool>>& powerUp) {
    int rows = grid.size();
    int cols = grid[0].size();
    int blockRows = powerUp.size();
    int blockCols = powerUp[0].size();

    for (int i = 0; i <= rows - blockRows; ++i) {
        for (int j = 0; j <= cols - blockCols; ++j) {
            bool match = true;
            for (int br = 0; br < blockRows; ++br) {
                for (int bc = 0; bc < blockCols; ++bc) {
                    if (grid[i + br][j + bc] != powerUp[br][bc]) {
                        match = false;
                        break;
                    }
                }
                if (!match) break;
            }
            if (match) return true;
        }
    }
    return false;
}

int GameController::clearCompletedRows(vector<vector<int>>& grid) {
    int rowsCleared = 0;
    for (int i = grid.size() ; i > 0; --i) {
        if (std::all_of(grid[i -1].begin(), grid[i - 1].end(), [](int val){ return val != 0; })) {
            grid.erase(grid.begin() + i - 1);
            grid.insert(grid.begin(), vector<int>(grid[0].size(), 0));
            ++rowsCleared;
        }
    }
    return rowsCleared;
}

int GameController::calculateOccupiedCell(const vector<vector<bool>>& shape){
    int occupiedCell = 0;
    for (int i = 0; i < shape.size(); i++){
        for(int j = 0; j < shape[0].size(); j++){
            if (shape[i][j] == 1)
                occupiedCell = occupiedCell + 1;
        }
    }
    return occupiedCell;
}






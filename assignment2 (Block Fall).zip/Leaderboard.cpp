#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>
#include "Leaderboard.h"

void Leaderboard::insert_new_entry(LeaderboardEntry * new_entry) {
    // TODO: Insert a new LeaderboardEntry instance into the leaderboard, such that the order of the high-scores
    //       is maintained, and the leaderboard size does not exceed 10 entries at any given time (only the
    //       top 10 all-time high-scores should be kept in descending order by the score).
    // TODO: Insert a new LeaderboardEntry instance into the leaderboard, maintaining order and limiting the size to 10 entries.


    if (head_leaderboard_entry == nullptr) {
        head_leaderboard_entry = new_entry;
        return;
    }

    LeaderboardEntry* current = head_leaderboard_entry;

    // if new entry has the highest score
    if (new_entry->score > head_leaderboard_entry->score){
        new_entry -> next_leaderboard_entry = head_leaderboard_entry;
        head_leaderboard_entry = new_entry;
    }
    else{

        while (current != nullptr && current->next_leaderboard_entry != nullptr){
            if (new_entry->score <= current->score && new_entry->score > current->next_leaderboard_entry->score){
                new_entry->next_leaderboard_entry = current -> next_leaderboard_entry;
                current-> next_leaderboard_entry = new_entry;
                break;
            }
            current = current->next_leaderboard_entry;
        }
        // add new entry to end of list
        if( current ->next_leaderboard_entry == nullptr){
            current->next_leaderboard_entry = new_entry;
        }
    }

    int count = 0;
    LeaderboardEntry* countCurrent = head_leaderboard_entry;
    while (countCurrent != nullptr){
        count +=1;
        countCurrent = countCurrent->next_leaderboard_entry;
    }



    if (count > 10){
        current = head_leaderboard_entry;
        LeaderboardEntry* prev = nullptr;

        while (current->next_leaderboard_entry != nullptr){
            prev = current;
            current = current->next_leaderboard_entry;
        }
        delete current;
        prev->next_leaderboard_entry = nullptr;
        }
}


void Leaderboard::write_to_file(const string& filename) {
    // TODO: Write the latest leaderboard status to the given file in the format specified in the PA instructions

    std::ofstream leaderBoardFile(filename);

    if (!leaderBoardFile.is_open()) {

        std::cout << "Error opening the file!" << std::endl;
        exit(-1);
    }

    LeaderboardEntry* printedEntry = head_leaderboard_entry;

    while (printedEntry != nullptr){
        leaderBoardFile << printedEntry->score << " " << printedEntry->last_played << " " << printedEntry->player_name << std::endl;
        printedEntry = printedEntry -> next_leaderboard_entry;
    }
    leaderBoardFile.close();

}

void Leaderboard::read_from_file(const string& filename) {
    // TODO: Read the stored leaderboard status from the given file such that the "head_leaderboard_entry" member
    //       variable will point to the highest all-times score, and all other scores will be reachable from it
    //       via the "next_leaderboard_entry" member variable pointer.

    std::ifstream leaderBoardFile(filename);
    if (!leaderBoardFile.is_open()) {
        return;

    }

    LeaderboardEntry* prevEntry = nullptr; // Pointer to the previous block

    std::string line;
    while (std::getline(leaderBoardFile, line)){
        std::istringstream iss(line);
        std::vector<std::string> words;
        std::string word;

        while (iss >> word) {
            if(!word.empty())
                words.push_back(word);
        }
        if (words.empty()) return;


        long unixTimestamp = std::strtol(words[1].c_str(), nullptr, 10);

        LeaderboardEntry* newLeaderBoardEntry = new LeaderboardEntry(stoul(words[0]), static_cast<std::time_t>(unixTimestamp), words[2]);

        if (head_leaderboard_entry == nullptr){
            head_leaderboard_entry = newLeaderBoardEntry;
        }
        else{
            if (prevEntry != nullptr){
                prevEntry->next_leaderboard_entry = newLeaderBoardEntry;
            }
        }
         prevEntry = newLeaderBoardEntry;
        //insert_new_entry(newLeaderBoardEntry);

    }
    if (leaderBoardFile.is_open()){
        leaderBoardFile.close();
    }
}

void Leaderboard::print_leaderboard() const {
    // TODO: Print the current leaderboard status to the standard output in the format specified in the PA instructions
    cout<<"Leaderboard\n"
          "-----------"<< endl;


    LeaderboardEntry* printedEntry = head_leaderboard_entry;

    char buffer[80];
    std::time_t lastPlayedTime = printedEntry->last_played;
    std::tm *timeInfo = std::localtime(&lastPlayedTime);

    // Format the time using strftime
    std::strftime(buffer, sizeof(buffer), "%H:%M:%S/%d.%m.%Y", timeInfo);

    int order = 1;
    while (printedEntry != nullptr){
        std::cout << order << ". " << printedEntry->player_name << " " << printedEntry->score << " " << buffer << std::endl;
        order +=1;
        printedEntry = printedEntry -> next_leaderboard_entry;
    }
}


Leaderboard::~Leaderboard() {
    // TODO: Free dynamically allocated memory used for storing leaderboard entries

    LeaderboardEntry* currentEntry = head_leaderboard_entry;
    while (currentEntry != nullptr) {
        LeaderboardEntry* temp = currentEntry;
        currentEntry = currentEntry->next_leaderboard_entry;
        delete temp;
    }
    head_leaderboard_entry = nullptr;

}

#ifndef PA2_GAMECONTROLLER_H
#define PA2_GAMECONTROLLER_H

#include "BlockFall.h"
#include <utility>

using namespace std;


class GameController {

public:
    bool play(BlockFall &game, const string &commands_file); // Function that implements the gameplay
    unsigned long highScore{0};

    void printGrid(vector<vector<int>>& grid);
    bool isPossible(const vector<vector<int> >& grid,Block* block, std::pair<int,int> topLeft,int heightToBeChecked, int widthToBeChecked);
    void handleMovement( vector<vector<int>>& grid,Block* block, std::pair<int,int> newTopLeft, int height, int width);
    void removeBlock(vector<vector<int>>& grid, Block* block);
    bool detectPowerUp(const std::vector<std::vector<int>>& grid, const std::vector<std::vector<bool>>& powerUp);
    int clearCompletedRows(vector<vector<int>>& grid) ;
    int calculateOccupiedCell(const vector<vector<bool>>& shape);
    std::time_t getCurrentTime();

};




#endif //PA2_GAMECONTROLLER_H

#include "BlockFall.h"

BlockFall::BlockFall(string grid_file_name, string blocks_file_name, bool gravity_mode_on, const string &leaderboard_file_name, const string &player_name) : gravity_mode_on(
        gravity_mode_on), leaderboard_file_name(leaderboard_file_name), player_name(player_name) {
    initialize_grid(grid_file_name);
    read_blocks(blocks_file_name);
    leaderboard.read_from_file(leaderboard_file_name);
}

void BlockFall::read_blocks(const string &input_file) {
    // TODO: Read the blocks from the input file and initialize "initial_block" and "active_rotation" member variables
    // TODO: For every block, generate its rotations and properly implement the multilevel linlisked t structure
    //       that represents the game blocks, as explained in the PA instructions.
    // TODO: Initialize the "power_up" member variable as the last block from the input file (do not add it to the linked list!)

    std::ifstream inputFile(input_file);
    if (!inputFile.is_open()) {
        std::cout << "Error opening the file!" << std::endl;
        exit(-1);
    }

    std::string line;
    std::vector<vector<bool>> currentShape;

    Block* prevBlock = nullptr; // Pointer to the previous block

    while (std::getline(inputFile, line)) {
        if (line.empty()) continue;

        // Parse the line to extract block information
        std::vector<bool> row;
        for (char character : line) {
            if (character == '0' || character == '1') {
                row.push_back(static_cast<bool>(character - '0'));
            }
        }

        if (!row.empty()) {
            currentShape.push_back(row);
        }

        // If the current shape has been fully read
        if (!line.empty() && line.back() == ']') {
            if (!currentShape.empty()) {
                Block* newBlock = new Block;
                newBlock->shape = currentShape;
                newBlock->next_block = nullptr;

                if (initial_block == nullptr) {
                    initial_block = newBlock; // set the head of linked list
                } else {
                    if (prevBlock != nullptr) {
                        prevBlock->next_block = newBlock; // Link the previous block to the new block
                    }
                }
                prevBlock = newBlock; // Update the previous block pointer

                currentShape.clear(); // Clear the shape for the next block
            }
        }
    }
    // Find the last block of the list and assign it to power_up variable
    Block* currentBlock = initial_block;
    while (currentBlock->next_block != nullptr){

        prevBlock = currentBlock;
        currentBlock = currentBlock->next_block;
        power_up = currentBlock->shape;
    }
    prevBlock->next_block = nullptr;


    // Delete power-up from linked list
    while (currentBlock->right_rotation != nullptr && currentBlock->right_rotation != currentBlock ) {
        Block* rightRotation = currentBlock->right_rotation;
        currentBlock->right_rotation = rightRotation->right_rotation; // Update link
        delete rightRotation; // Delete the rotation
    }
    delete currentBlock; // Delete the block

    // Iterate through each block and generate its rotation
    Block* current = initial_block;

    while (current != nullptr){
        Block* originalBlock = current;

        // Generate all rotations of each block
        for (int i = 0; i < 4; ++i){

            Block* newRotation = new Block;
            newRotation->shape = rotateRight(current->shape);
            newRotation->next_block = originalBlock->next_block;

            if ( newRotation->shape == originalBlock -> shape){
                if (originalBlock -> right_rotation == nullptr){
                    originalBlock -> right_rotation = originalBlock;
                    originalBlock -> left_rotation = originalBlock;

                }
                else{
                    originalBlock-> left_rotation = current;
                    current->right_rotation = originalBlock;
                }
                delete newRotation;
                break;
            }
            else{
                current->right_rotation = newRotation;
                newRotation->left_rotation = current;
            }
            current = newRotation;
        }
        current = originalBlock->next_block;
    }



}

void BlockFall::initialize_grid(const string &input_file) {

    // TODO: Initialize "rows" and "cols" member variables
    // TODO: Initialize "grid" member variable using the command-line argument 1 in main

    std::ifstream inputFile(input_file);
    if (!inputFile.is_open()) {
        std::cout << "Error opening the file!" << std::endl;
        exit(-1);
    }

    std::string line;
    while (std::getline(inputFile, line)) {

        // Process each line read from the file
        rows++; // increment row counter by one
        cols = 0;

        std::vector<int> row;

        for(char cell: line){
            if (cell != ' ' && cell != '\n'){
                row.push_back(cell - '0');
                cols++; // increment column counter by one
            }
        }
        grid.push_back(row);
    }
    inputFile.close(); // Close the file stream
}

vector<vector<bool>> BlockFall::rotateRight(vector<vector<bool>>& shape) {
    int rowNum = shape.size();
    int colNum = shape[0].size();

    // Transpose the matrix
    vector<vector<bool>> rotated(colNum, vector<bool>(rowNum));
    for (int i = 0; i < rowNum; ++i) {
        for (int j = 0; j < colNum; ++j) {
            rotated[j][rowNum - i - 1] = shape[i][j];
        }
    }
    return rotated;
}



BlockFall::~BlockFall() {
    // TODO: Free dynamically allocated memory used for storing game blocks

    // Free dynamically allocated memory used for storing game blocks
    Block* currentBlock = initial_block;

    while (currentBlock != nullptr) {
        Block* temp = currentBlock;

        // Handle right rotations
        while (temp->right_rotation != nullptr && temp->right_rotation != temp ) {
            Block* rightRotation = temp->right_rotation;
            temp->right_rotation = rightRotation->right_rotation; // Update link

            delete rightRotation; // Delete the rotation
        }
        currentBlock = currentBlock->next_block;
        delete temp; // Delete the block

    }
    initial_block = nullptr; // Set the head of the linked list to nullptr
}



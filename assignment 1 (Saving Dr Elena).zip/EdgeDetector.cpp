// EdgeDetector.cpp
#include <iostream>
#include "EdgeDetector.h"
#include <cmath>

#include "EdgeDetector.h"
#include <cmath>

// Default constructor
EdgeDetector::EdgeDetector() : sobel_height(3), sobel_width(3){

    // Create a list for using at initialization
    double gx_list[3][3] = {{-1.0, 0.0, 1.0},
                            {-2.0, 0.0, 2.0},
                            {-1.0, 0.0, 1.0}};
    // Allocate memory for Gx
    sobel_gx = new double*[sobel_height];
    for (int i = 0; i < sobel_height; ++i) {
        sobel_gx[i] = new double[sobel_width];
    }

    // Initialization
    for (int i = 0; i < sobel_height; ++i) {
        for (int j = 0; j < sobel_width; j++) {
            sobel_gx[i][j] = gx_list[i][j];
        }
    }

    // Create a list for using at initialization
    double gy_list[3][3] = {{-1.0, -2.0, -1.0},
                            {0.0, 0.0, 0.0},
                            {1.0, 2.0, 1.0}};

    // Allocate memory for Gy
    sobel_gy = new double*[sobel_height];
    for (int i = 0; i < sobel_height; ++i) {
        sobel_gy[i] = new double[sobel_width];
    }

    // Initialization
    for (int i = 0; i < sobel_height; ++i) {
        for (int j = 0; j < sobel_width; j++) {
            sobel_gy[i][j] = gy_list[i][j];
        }
    }



}

// Destructor
EdgeDetector::~EdgeDetector() {
    if (sobel_gx != nullptr) {

        // Deallocate the allocated memory for the Gx
        for (int i = 0; i < 3; ++i) {
            delete[] sobel_gx[i];
        }
        delete[] sobel_gx;
        sobel_gx = nullptr;

    }

    if (sobel_gy != nullptr) {

        // Deallocate the allocated memory for the Gy
        for (int i = 0; i < 3; ++i) {
            delete[] sobel_gy[i];
        }
        delete[] sobel_gy;
        sobel_gy = nullptr;

    }
}

// Detect Edges using the given algorithm
std::vector<std::pair<int, int>> EdgeDetector::detectEdges(const ImageMatrix& input_image) {

    // Create convolution object for horizontal edge detection
    Convolution horizontal_convolve(sobel_gx, sobel_height, sobel_width, 1, true);

    // Generate horizontal edge response
    ImageMatrix horizontal_edge_response = horizontal_convolve.convolve(input_image);

    // Create convolution object for vertical edge detection
    Convolution vertical_convolve(sobel_gy, sobel_height, sobel_width, 1, true);

    // Generate vertical edge response
    ImageMatrix vertical_edge_response = vertical_convolve.convolve(input_image);

    // Calculate gradient magnitudes and threshold
    double gradient_sum = 0.0;
    for (int i = 0; i < input_image.get_height(); ++i) {
        for (int j = 0; j < input_image.get_width(); j++){
            double gradient = sqrt(pow(horizontal_edge_response.get_data(i, j), 2) + pow(vertical_edge_response.get_data(i, j), 2));
            gradient_sum += gradient;
        }
    }
    double threshold = gradient_sum/(horizontal_edge_response.get_height() * horizontal_edge_response.get_width() );

    // Declare a vector called edge_pixels to keep pixel indexes
    std::vector<std::pair<int, int>> edge_pixels;

    // Append to edge_pixels all pixels with gradient above the threshold
    for (int i = 0; i < input_image.get_height(); ++i) {
        for (int j = 0; j < input_image.get_width(); j++){
            double gradient = sqrt(pow(horizontal_edge_response.get_data(i, j), 2) + pow(vertical_edge_response.get_data(i, j), 2));
            if(gradient > threshold){
                edge_pixels.push_back(std::make_pair(i, j));
            }
        }
    }

    return edge_pixels;

}


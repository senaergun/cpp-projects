#include "ImageSharpening.h"
#include <string>
#include <iostream>

// Default constructor
ImageSharpening::ImageSharpening() : kernel_height(3), kernel_width(3){

    // Allocate memory for the blurring kernel
    blurring_kernel = new double*[kernel_height];
    for (int i = 0; i < kernel_height; ++i) {
        blurring_kernel[i] = new double[kernel_width];
    }

    // Initialize the blurring kernel
    for (int i = 0; i < kernel_height; ++i) {
        for (int j = 0; j < kernel_width; j++) {
            blurring_kernel[i][j] = 1.0/9.0;
        }
    }


}

ImageSharpening::~ImageSharpening(){
    if(blurring_kernel != nullptr){
        // Deallocate the allocated memory for the blurring kernel
        for (int i = 0; i < kernel_height; ++i) {
            delete[] blurring_kernel[i];
        }
        delete[] blurring_kernel;
    }

}

ImageMatrix ImageSharpening::sharpen(const ImageMatrix& input_image, double k) {

    // Create convolution object for blurring
    Convolution blurring_convolve(blurring_kernel, kernel_height, kernel_width, 1, true);

    // Generate noisy image
    ImageMatrix blurred_image = blurring_convolve.convolve(input_image);

    //std::cout<< "blurred image" << std::endl;
    //blurred_image.PrintImageData();

    // Calculate the sharpened image
    ImageMatrix substracted_image = input_image - blurred_image;

    //std::cout<< "substarcted image" << std::endl;
    //substracted_image.PrintImageData();

    ImageMatrix multiplied_image = substracted_image * k;
    ImageMatrix sharpened_image = input_image + multiplied_image;

    //std::cout<< "multiplied image" << std::endl;
    //multiplied_image.PrintImageData();

    // Clipping
    for (int i = 0; i < sharpened_image.get_height(); ++i) {
        for (int j = 0; j < sharpened_image.get_width(); j++) {
            if (sharpened_image.get_data(i, j) > 255.0)
                sharpened_image.set_data(i, j, 255.0);
            if(sharpened_image.get_data(i,j) < 0.0)
                sharpened_image.set_data(i,j, 0);
        }
    }
    //std::cout<< "sharpened image-clipped" << std::endl;
    //sharpened_image.PrintImageData();

    return sharpened_image;
}

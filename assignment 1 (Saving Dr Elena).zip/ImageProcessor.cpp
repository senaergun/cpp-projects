#include "ImageProcessor.h"


ImageProcessor::ImageProcessor() {

}

ImageProcessor::~ImageProcessor() {

}


std::string ImageProcessor::decodeHiddenMessage(const ImageMatrix &img) {


    // Generate sharpened image
    ImageSharpening sharpening;
    ImageMatrix sharpened = sharpening.sharpen(img, 2.0);

    // Generate vector holding edge pixels
    EdgeDetector edge_detector;
    std::vector<std::pair<int, int>>  edge_pixels = edge_detector.detectEdges(sharpened);

    // Generate string holding decoded message
    DecodeMessage decoding;
    std::string decoded_message = decoding.decodeFromImage(sharpened, edge_pixels);
    return decoded_message;
}

ImageMatrix ImageProcessor::encodeHiddenMessage(const ImageMatrix &img, const std::string &message) {

    // Generate sharpened image
    ImageSharpening sharpening;
    ImageMatrix sharpened = sharpening.sharpen(img, 2);

    // Generate vector holding edge pixels
    EdgeDetector edge_detector;
    std::vector<std::pair<int, int>>  edge_pixels = edge_detector.detectEdges(sharpened);

    // Generate encoded image
    EncodeMessage encoding;
    ImageMatrix encoded_image = encoding.encodeMessageToImage(img, message, edge_pixels);

    return encoded_image;


}

#include <iostream>

#include "Convolution.h"

// Default constructor
Convolution::Convolution() : kernel(nullptr), kernelHeight(0), kernelWidth(0), stride(1), padding(true){

}

// Parametrized constructor for custom kernel and other parameters
Convolution::Convolution(double** customKernel, int kh, int kw, int stride_val, bool pad)
    : kernelHeight(kh), kernelWidth(kw), stride(stride_val), padding(pad){

    // Allocate memory for the kernel
    kernel = new double*[kernelHeight];
    for (int i = 0; i < kernelHeight; ++i) {
        kernel[i] = new double[kernelWidth];
    }

    //Copy values from customKernel to kernel
    for (int i = 0; i < kernelHeight; ++i) {
        for (int j = 0; j < kernelWidth; j++) {
            kernel[i][j] = customKernel[i][j];
        }
    }
}

// Destructor
Convolution::~Convolution() {

    if (nullptr != kernel) {

        // Deallocate the allocated memory for the kernel
        for (int i = 0; i < kernelHeight; ++i) {
            delete[] kernel[i];
        }
        delete[] kernel;

    }

}

// Copy constructor
Convolution::Convolution(const Convolution &other)
    : kernelHeight(other.kernelHeight), kernelWidth(other.kernelWidth), stride(other.stride), padding(other.padding){

    // Allocate memory for the kernel
    kernel = new double*[kernelHeight];
    for (int i = 0; i < kernelHeight; ++i) {
        kernel[i] = new double[kernelWidth];
    }

    //Copy values from customKernel to kernel
    for (int i = 0; i < kernelHeight; ++i) {
        for (int j = 0; j < kernelWidth; j++) {
            kernel[i][j] = other.kernel[i][j];
        }
    }

}

// Copy assignment operator
Convolution& Convolution::operator=(const Convolution &other) {

    this->kernelHeight = other.kernelHeight;
    this->kernelWidth = other.kernelWidth;
    this->stride = other.stride;
    this->padding = other.padding;

    // Deallocate the allocated memory for the kernel (if any)
    if (this->kernel != nullptr){
        for (int i = 0; i < kernelHeight; ++i) {
            delete[] kernel[i];
        }
        delete[] kernel;
    }

    // Allocate memory for the kernel
    kernel = new double*[kernelHeight];
    for (int i = 0; i < kernelHeight; ++i) {
        kernel[i] = new double[kernelWidth];
    }


    // Copy data from other object to kernel
    for (int i = 0; i < kernelHeight; ++i) {
        for (int j = 0; j < kernelWidth; j++) {
            kernel[i][j] = other.kernel[i][j];
        }
    }

    return *this;

}


// Convolve Function: Responsible for convolving the input image with a kernel and return the convolved image.
ImageMatrix Convolution::convolve(const ImageMatrix& input_image) const {

    int imageHeight = input_image.get_height();
    int imageWidth = input_image.get_width();
    int resultHeight = (imageHeight - kernelHeight + (2 * int(padding)))/stride + 1;
    int resultWidth = (imageWidth - kernelWidth + (2 * int(padding)))/stride + 1;

    // Update the dimensions if padding is true
    if (padding) {

        imageHeight += 2;
        imageWidth += 2;
    }

    ImageMatrix new_input_image(imageHeight, imageWidth);

    // Update the input image if padding is true
    if (padding){

        for (int i = 1; i < imageHeight -1 ; i++){
            for (int j = 1; j < imageWidth -1 ; j ++){
                double new_value = input_image.get_data(i-1, j-1);
                new_input_image.set_data(i, j, new_value);
            }
        }

    } else {

        new_input_image = input_image;
    }

    ImageMatrix resultImage(resultHeight, resultWidth);

    for (int i = 0; i < resultHeight; i++){

        for (int j = 0; j < resultWidth; j++) {

            double sum = 0.0;

            for (int m = 0; m < kernelHeight; m++) {

                for (int n = 0; n < kernelWidth; n++) {

                    int inputX = i * stride + m;
                    int inputY = j * stride + n;

                    // Check the image bounds
                    if ((inputX >= 0 && inputX < new_input_image.get_height() && inputY >= 0 && inputY < new_input_image.get_width())) {
                        double inputValue = new_input_image.get_data(inputX, inputY);
                        sum += inputValue * kernel[m][n];

                    }
                }
            }
            resultImage.set_data(i, j, sum);

        }

    }

    return resultImage;
}

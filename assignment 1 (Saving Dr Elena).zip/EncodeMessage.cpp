#include "EncodeMessage.h"
#include <cmath>
#include <iostream>
#include <bitset>



// Default Constructor
EncodeMessage::EncodeMessage() {

}

// Destructor
EncodeMessage::~EncodeMessage() {

}

// Function to encode a message into an image matrix
ImageMatrix EncodeMessage::encodeMessageToImage(const ImageMatrix &img, const std::string &message, const std::vector<std::pair<int, int>>& positions) {

    ImageMatrix encoded_image(img);
    int index = 0;
    std::string manipulated_message = "";
    std::string transformed_binary_string = "";

    while (index < message.length()){
        int ascii_value = static_cast<int>(message[index]);
        if(isPrime(index)){
            int new_ascii = ascii_value + fib(index);

            // Adjust ASCII values if necessary
            if (new_ascii <= 32) {

                new_ascii += 33;

            } else if (new_ascii >= 127) {

                new_ascii = 126;

            }
            manipulated_message += static_cast<char>(new_ascii);

        } else {

            manipulated_message += static_cast<char>(ascii_value);

        }
        index++;

    }


    int shift = manipulated_message.length() / 2;
    if (manipulated_message.length() % 2 == 0){
        manipulated_message = manipulated_message.substr(manipulated_message.length() - shift, shift) + manipulated_message.substr(0, shift);
        }
    else{
        manipulated_message = manipulated_message.substr(manipulated_message.length() - shift, shift) + manipulated_message.substr(0, shift + 1);
        }

    // Convert the characters in the manipulated message to binary string
    for(auto character: manipulated_message){
        int ascii_value = static_cast<int>(character);
        std::string binary = std::bitset<7>(ascii_value).to_string();
        transformed_binary_string += binary;
    }

    // Update the least significant values of edge pixels and configure the encoded image
    int target_index = 0;
    for (auto pair: positions) {
        if (target_index >= transformed_binary_string.length())
            break;

        int i = pair.first;
        int j = pair.second;
        int old_value = img.get_data(i,j);
        int new_value;
        char lsb = transformed_binary_string[target_index];
        if(lsb == '1'){
            new_value = old_value | 1; // update the least significant bit of old value to 1
        }else {
            new_value = old_value & ~1; // update the least significant bit of old value to 0
        }

        encoded_image.set_data(i,j,new_value);
        target_index++;

    }

    return encoded_image;
}

// Return true if n is a prime number and false if it is not
bool EncodeMessage::isPrime(int n){
    // Corner case
    if (n <= 1)
        return false;

    // Check from 2 to n-1
    for (int i = 2; i <= n / 2; i++)
        if (n % i == 0)
            return false;

    return true;
}

// Return n'th Fibonacci number
int EncodeMessage::fib(int n)
{
    if (n <= 1)
        return n;
    return fib(n - 1) + fib(n - 2);
}

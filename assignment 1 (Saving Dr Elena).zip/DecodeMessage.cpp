// DecodeMessage.cpp

#include "DecodeMessage.h"
#include <iostream>

// Default constructor
DecodeMessage::DecodeMessage() {
    // Nothing specific to initialize here
}

// Destructor
DecodeMessage::~DecodeMessage() {
    // Nothing specific to clean up
}


std::string DecodeMessage::decodeFromImage(const ImageMatrix& image, const std::vector<std::pair<int, int>>& edgePixels) {

    std::string binary_string = "";
    std::string decoded_message = "";

    for (auto pair: edgePixels) {
        int i = pair.first;
        int j = pair.second;
        double pixel = image.get_data(i, j);

        // Extract the LSB from the pixel value and append to binary string
        int lsb = static_cast<int>(pixel) & 1;
        binary_string += std::to_string(lsb);
    }

    // Pad the binary string with leading zeros to ensure 7-bit segments
    while (binary_string.length() % 7 != 0) {
        binary_string = "0" + binary_string;
    }


    // Convert each 7 bit segment to ASCII value and adjust if needed
    for (size_t i = 0; i < binary_string.length(); i += 7) {
        std::string segment = binary_string.substr(i, 7);
        int ascii_value = std::stoi(segment, nullptr, 2);

        // Adjust ASCII values if necessary
        if (ascii_value <= 32) {
            ascii_value += 33;
        } else if (ascii_value >= 127) {
            ascii_value = 126;
        }

        // Convert ASCII to character and append to the decoded message
        char decodedChar = static_cast<char>(ascii_value);
        decoded_message += decodedChar;
    }

    return decoded_message;

}

